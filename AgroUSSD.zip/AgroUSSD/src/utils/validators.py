"""Input validation utilities"""
