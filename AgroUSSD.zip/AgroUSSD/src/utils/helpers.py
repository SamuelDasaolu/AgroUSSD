"""Common helper functions"""
