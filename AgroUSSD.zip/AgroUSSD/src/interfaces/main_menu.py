"""Main menu interface"""
