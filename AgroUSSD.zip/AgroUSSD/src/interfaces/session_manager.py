"""Session state management"""
