from src.models.farmer import Farmer
from src.models.buyer import Buyer
from src.interfaces.farmer_menu import farmer_menu
from src.interfaces.buyer_menu import buyer_menu
from src.interfaces.session_manager import SessionManager

session_manager = SessionManager()

def ussd_menu(phone_number: str, text: str):
    session = session_manager.get_session(phone_number)
    if not session:
        session = session_manager.start_session(phone_number)
        return "CON Welcome to AgroUSSD\n1. Register\n2. Login"

    state = session["state"]

    if state == "main_menu":
        if text == "1":
            session_manager.update_session(phone_number, "state", "register_role")
            return "CON Register as:\n1. Farmer\n2. Buyer"
        elif text == "2":
            session_manager.update_session(phone_number, "state", "login_role")
            return "CON Login as:\n1. Farmer\n2. Buyer"
        else:
            return "END Invalid option."

    elif state == "register_role":
        if text == "1":
            session_manager.update_session(phone_number, "state", "register_farmer")
            return "CON Enter Name and PIN separated by *"
        elif text == "2":
            session_manager.update_session(phone_number, "state", "register_buyer")
            return "CON Enter Name and PIN separated by *"
        else:
            return "END Invalid option."

    elif state == "register_farmer":
        parts = text.split("*")
        if len(parts) == 2:
            name, pin = parts
            farmer = Farmer(name, phone_number, pin)
            farmer.register()
            session_manager.update_session(phone_number, "user", farmer)
            return "END Farmer registered successfully."
        return "END Invalid input."

    elif state == "register_buyer":
        parts = text.split("*")
        if len(parts) == 2:
            name, pin = parts
            buyer = Buyer(name, phone_number, pin)
            buyer.register()
            session_manager.update_session(phone_number, "user", buyer)
            return "END Buyer registered successfully."
        return "END Invalid input."

    elif state == "login_role":
        if text == "1":
            session_manager.update_session(phone_number, "state", "login_farmer")
            return "CON Enter PIN:"
        elif text == "2":
            session_manager.update_session(phone_number, "state", "login_buyer")
            return "CON Enter PIN:"
        else:
            return "END Invalid option."

    elif state == "login_farmer":
        farmer = Farmer("", phone_number, text)
        if farmer.authenticate(text):
            session_manager.update_session(phone_number, "user", farmer)
            session_manager.update_session(phone_number, "state", "farmer_menu")
            return "CON Farmer Menu\n1. Add Produce\n2. View Produce"
        return "END Authentication failed."

    elif state == "login_buyer":
        buyer = Buyer("", phone_number, text)
        if buyer.authenticate(text):
            session_manager.update_session(phone_number, "user", buyer)
            session_manager.update_session(phone_number, "state", "buyer_menu")
            return "CON Buyer Menu\n1. Place Order\n2. View Orders"
        return "END Authentication failed."

    elif state == "farmer_menu":
        farmer = session["user"]
        return farmer_menu(farmer, text)

    elif state == "buyer_menu":
        buyer = session["user"]
        return buyer_menu(buyer, text)

    return "END Session error."
