"""Buyer-specific menus"""
