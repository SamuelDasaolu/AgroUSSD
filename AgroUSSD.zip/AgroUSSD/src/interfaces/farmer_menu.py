"""Farmer-specific menus"""
