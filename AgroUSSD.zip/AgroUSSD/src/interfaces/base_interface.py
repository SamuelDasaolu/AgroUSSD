"""Abstract USSDInterface class"""
