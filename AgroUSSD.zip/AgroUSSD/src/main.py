"""Main application entry point"""
