"""User management operations"""
