"""Market price operations"""
