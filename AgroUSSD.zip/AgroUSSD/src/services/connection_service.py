"""Buyer-farmer connections"""
