"""Abstract User model"""

from abc import ABC, abstractmethod

class User(ABC):
    pass
