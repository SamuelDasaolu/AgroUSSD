"""Harvest model"""
