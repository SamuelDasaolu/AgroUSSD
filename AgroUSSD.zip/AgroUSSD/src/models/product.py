"""Abstract Product model"""
