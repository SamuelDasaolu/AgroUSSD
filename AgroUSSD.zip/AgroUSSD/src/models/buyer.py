"""Buyer model inheriting User"""
