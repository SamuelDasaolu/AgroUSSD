"""Farmer model inheriting User"""
