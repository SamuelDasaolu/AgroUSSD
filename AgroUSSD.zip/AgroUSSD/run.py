"""Launcher script"""
