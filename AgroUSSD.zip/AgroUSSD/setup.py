"""Installation script"""
