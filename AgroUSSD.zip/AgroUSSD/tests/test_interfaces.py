"""Tests for interfaces"""
