class SessionManager:
    def __init__(self):
        self.sessions = {}

    def start_session(self, phone_number):
        self.sessions[phone_number] = {"state": "main_menu", "user": None}
        return self.sessions[phone_number]

    def get_session(self, phone_number):
        return self.sessions.get(phone_number)

    def update_session(self, phone_number, key, value):
        if phone_number in self.sessions:
            self.sessions[phone_number][key] = value

    def end_session(self, phone_number):
        if phone_number in self.sessions:
            del self.sessions[phone_number]
