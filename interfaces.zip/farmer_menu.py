from src.models.farmer import Farmer

def farmer_menu(farmer: Farmer, text: str):
    if text == "1":
        return "CON Enter product name:"
    elif text.startswith("1*"):
        parts = text.split("*")
        if len(parts) == 2:
            return "CON Enter quantity:"
        elif len(parts) == 3:
            product_name = parts[1]
            quantity = int(parts[2])
            farmer.add_produce(product_name, quantity)
            return "END Product added successfully."
    elif text == "2":
        produce = farmer.view_produce()
        if not produce:
            return "END No produce available."
        return "END " + ", ".join([f"{k}: {v}" for k, v in produce.items()])
    else:
        return "END Invalid option."
