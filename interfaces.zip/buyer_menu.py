from src.models.buyer import Buyer

def buyer_menu(buyer: Buyer, text: str):
    if text == "1":
        return "CON Enter Farmer ID:"
    elif text.startswith("1*"):
        parts = text.split("*")
        if len(parts) == 2:
            return "CON Enter product name:"
        elif len(parts) == 3:
            return "CON Enter quantity:"
        elif len(parts) == 4:
            farmer_id = parts[1]
            product_name = parts[2]
            quantity = int(parts[3])
            buyer.place_order(farmer_id, product_name, quantity)
            return "END Order placed successfully."
    elif text == "2":
        orders = buyer.view_orders()
        if not orders:
            return "END No orders found."
        return "END " + ", ".join([f"{o['product']}: {o['quantity']}" for o in orders])
    else:
        return "END Invalid option."
